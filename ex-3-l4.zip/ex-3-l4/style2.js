import { StyleSheet } from "react-native";
import Constants from 'expo-constants';

const styles2 = StyleSheet.create({
  container: {
    flexDirection: "collumn",
    flex: 1,
  },
  container2: {
    flexDirection: "row",
    flex: 1,
  },
  top: {
    flex: 1,
   justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#ffffbb',
  },
  middle: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#eeeeaa',
  },
  bottom: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#bbddaa',
  }
});
export default styles2;
