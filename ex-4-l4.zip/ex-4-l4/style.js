import { StyleSheet } from "react-native";
import Constants from 'expo-constants';

const styles = StyleSheet.create({
  container: {
    flexDirection: "collumn",
    flex: 1,
  },
  container2: {
    flexDirection: "row",
    flex: 1,
  },
  top: {
    flex: 0.1,
   justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#FFA07A',
  },
  middle: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#F08080',
  },
  bottom: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#FF6347',
  }
});
export default styles;
