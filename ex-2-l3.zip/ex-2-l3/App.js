import { Text, SafeAreaView, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import * as linking from "expo-linking";

const telefone = "+5511999999999";
const url = `whatsapp://send?phone=${telefone}`;

export default function App() {
  async function click(){
    try {
      await linking.openURL(url);
    }catch(err){
      Alert.alert("ERROR","deu erro e nao abriu");
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        numero do pelé no zap zap
      </Text>
      <TouchableOpacity onPress={click} style={styles.button}>
          <Text> pelé </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  button: {
    width: 100,
    borderWidth: 1,
    backgroundColor: "#5555ff",
    borderRadius: 5,
    padding: 5,
    alignItems: "center",
    alignSelf: "center",
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
