import React, { useState, useEffect } from "react";
import { Text, SafeAreaView, StyleSheet, View } from 'react-native';
import * as ScreenOrientation from "expo-screen-orientation";

const Orientation: React.FC = () => {
const [mode, setMode] = useState("");
useEffect(() => {
// Chama a função que define a orientação inicial
  readOrientation();
// Limpa o listener quando o componente for desmontado
  return () => {
   ScreenOrientation.removeOrientationChangeListener(subscription);
  };
}, []);
// Define um listener para mudanças de orientação
const subscription = ScreenOrientation.addOrientationChangeListener(
  ({ orientationInfo }) => {
    if (
      orientationInfo.orientation === ScreenOrientation.Orientation.PORTRAIT_UP||     orientationInfo.orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN) {
      setMode("portrait");
}   else if (
        orientationInfo.orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT||orientationInfo.orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT) {
        setMode("landscape");
    }
  }
);

const readOrientation = async () => {
  const orientation = await ScreenOrientation.getOrientationAsync();
    if (
      orientation === ScreenOrientation.Orientation.PORTRAIT_UP ||
      orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN
    ) {
      setMode("portrait");
  } else if (
      orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT ||
      orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT
  ) {
    setMode("landscape");
  }
};
if (mode === "landscape"){
  return (
    <SafeAreaView style={styles.container2}>
      <View style={styles.top}>
        <Text>Top</Text>
      </View>
      <View style={styles.middle}>
        <Text>Middle</Text>
      </View>
      <View style={styles.bottom}>
        <Text>Botton</Text>
      </View> 
    </SafeAreaView>
  );
}else if (mode === "portrait"){
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.top}>
        <Text>Top</Text>
      </View>
      <View style={styles.middle}>
        <Text>Middle</Text>
      </View>
      <View style={styles.bottom}>
        <Text>Botton</Text>
      </View> 
    </SafeAreaView>
  );
}
};
export default Orientation;

const styles = StyleSheet.create({
  container: {
    flexDirection: "collumn",
    flex: 1,
  },
  container2: {
    flexDirection: "row",
    flex: 1,
  },
  top: {
    flex: 1,
   justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#FFA07A',
  },
  middle: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#F08080',
  },
  bottom: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: '#FF6347',
  }
});

