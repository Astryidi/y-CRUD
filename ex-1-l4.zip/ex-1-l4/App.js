import React, { useState, useEffect } from "react";
import { Text, SafeAreaView, StyleSheet } from 'react-native';
import * as ScreenOrientation from "expo-screen-orientation";

const Orientation: React.FC = () => {
const [mode, setMode] = useState("");
useEffect(() => {
// Chama a função que define a orientação inicial
  readOrientation();
// Limpa o listener quando o componente for desmontado
  return () => {
   ScreenOrientation.removeOrientationChangeListener(subscription);
  };
}, []);
// Define um listener para mudanças de orientação
const subscription = ScreenOrientation.addOrientationChangeListener(
  ({ orientationInfo }) => {
    if (
      orientationInfo.orientation === ScreenOrientation.Orientation.PORTRAIT_UP||     orientationInfo.orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN) {
      setMode("portrait");
}   else if (
        orientationInfo.orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT||orientationInfo.orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT) {
        setMode("landscape");
    }
  }
);

const readOrientation = async () => {
  const orientation = await ScreenOrientation.getOrientationAsync();
    if (
      orientation === ScreenOrientation.Orientation.PORTRAIT_UP ||
      orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN
    ) {
      setMode("portrait");
  } else if (
      orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT ||
      orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT
  ) {
    setMode("landscape");
  }
};
if (mode === "landscape"){
  return (
    <SafeAreaView style={styles.container2}>
      <Text>Tela em modo {mode}</Text>
    </SafeAreaView>
  );
}else if (mode === "portrait"){
  return (
    <SafeAreaView style={styles.container}>
      <Text>Tela em modo {mode}</Text>
    </SafeAreaView>
  );
}
};
export default Orientation;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#FFA500',
    padding: 8,
    alignItems: "center",
  },
  container2: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#1E90FF',
    padding: 8,
    alignItems: "center",
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
